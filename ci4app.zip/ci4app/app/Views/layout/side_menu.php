<header id="header">
    <div class="container">

        <h1><a href="<?= base_url() ?>home">Aisya Syakira Purnama</a></h1>
        <h2>Saya Mahasiswa aktif 2021 <span>Universitas Muhammadiyah Sukabumi</span>Teknik Informatika</h2>

        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link active" href="#header">Beranda</a></li>
                <li><a class="nav-link" href="#about">Tentang Saya</a></li>
                <li><a class="nav-link" href="#resume">Pendidikan</a></li>
                <li><a class="nav-link" href="#services">Layanan</a></li>
                <li><a class="nav-link" href="#portfolio">Project</a></li>
                <li><a class="nav-link" href="#contact">Kontak</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

        <div class="social-links">
            <a href="https://www.instagram.com/syakincaa?igsh=MThhaGNuM3ZkcTBkYQ==" class="gole"><i class="bi bi-instagram"></i></a>
            <a href="https://github.com/AisyaSyakira" class="github"><i class="bi bi-github"></i></a>
            <a href="https://youtube.com/@aisyasyakirapurnama4420?si=jzZLIVwdgnBh_qMJ" class="youtube"><i class="bi bi-youtube"></i></a>
            <a href="https://wa.me/+6285715389629?text=Halo.. Saya ingin bertanya terkait website portofolio diri. Mohon keterangan lebih lengkapnya.." class="whatsapp"><i class="bi bi-whatsapp"></i></a>
        </div>

    </div>
</header><!-- End Header -->