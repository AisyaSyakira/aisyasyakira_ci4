<?php

namespace App\Controllers;

use App\Models\User_model;

class Home extends BaseController
{
    public function index()
    {

        $userModel = new User_model();
        $users = $userModel->getuser();


        $data = array(
            // 'title' => 'Aisya Syakira',
            'users' => $users
        );
        return view('layout/wrapper', $data);
    }
}
